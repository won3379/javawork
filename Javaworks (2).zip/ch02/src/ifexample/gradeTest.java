package ifexample;

import java.util.Scanner;

public class gradeTest {

	public static void main(String[] args) {
		// 
//점수를 입력받아 학점을 출력하는 프로그램
		/*A(90점 이상)
		B(80점이상)
		C(70점 이상)
		D(60점이상)*/
		//변수 int점수grade,문자형charscore(학점abcd)
		Scanner sc =new Scanner(System.in);
		System.out.print("점수를 입력하세요:");
		int score=sc.nextInt();
		char grade = 'A'; //String grade = "A"와 같다
		
		
		
				
		 sc.close();
	}
	

}
