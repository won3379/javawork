package classes.methods;

public class UseHello {

	public static void main(String[] args) {
		// Hello 클래스 사용	
		Hello say = new Hello();
		say.sayHello();
		say.sayHello("Elsa");
		say.sayHello("장그래");
	}

}
