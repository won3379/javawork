package hello;

// 파일(class) 이름의 첫글자는 대문자로 함.
//표기법(낙타-카멜): 단어가 합성될 때 첫글자는 대문자로 함 
public class HelloWorld {

	//main() 함수 : 메모리(주기억장치)에서 실행
	public static void main(String[] args) {
		// 한줄 주석 -문자를 출력하는 프로그램 만들기 
        System.out.println("Hello~ Java");  //다음 줄에 출력
        System.out.println("안녕 자바");
        
        // 자기소개 
        System.out.println("이름 : 서정원");
        System.out.println("주소 :광주시 태전동 "); 
	}

}
