package whileexample;

public class whileEx1 {

	public static void main(String[] args) {
		
		// while 반복문 
		// 초기 값 , 종료조건, 증감값(1증가,1감소)
		
		int i =0;
		while(i<100) { //f(true)
			
		//	i=i+1;
			i++;
			System.out.println(i);
			
		}
	}

}
