package polymorphism.fruits;

public class Grape extends Fruit{
	
	public Grape() {
		name = "포도";
		weight ="700g";
		price = 5000; 
	}
}
