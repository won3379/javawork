package inheritance.q4;

public class Employee {

	public String name;
	public String grade;
	public Employee(String name) {
		this.name =name; //세미콜론
		
	}
}

