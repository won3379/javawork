package protectedex.pack1;

public class B {
	
	public void method() {
		A a = new A();
		a.field = "yes";
		a.method();
	}
}
