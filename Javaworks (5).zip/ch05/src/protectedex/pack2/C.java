package protectedex.pack2;

import protectedex.pack1.A;

public class C {
	public void method() {
		A a =new A(); //A를 사용할 수 없음
	}
}
