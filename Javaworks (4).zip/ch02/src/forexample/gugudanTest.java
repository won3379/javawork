package forexample;

public class gugudanTest {
public static void main(String[] args) {
	// 단일 for()
	/* 
	 * 3x1=3
	 * 3for(초기값;종료값;증감값){
	 * 3x1=3
	 * 3x2=6
	 * 3x3=9
	 * 3x4=12
	 * 3x5=15
	 * 
	 * */
	int dan =3;
	 for(int i=1; i<=9; i++) {	 
		 System.out.println(dan+"x"+i+"="+(dan*i));
	 
	  
}

	 
	
	
}
}
