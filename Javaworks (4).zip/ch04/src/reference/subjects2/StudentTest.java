package reference.subjects2;

import classes.Student.Student;

public class StudentTest {

	public static void main(String[] args) {
		Student kim =new Student(101, "김대한");
		
		kim.addSubject("국어" ,90);
		kim.addSubject("수학" ,80);
		kim.addSubject("과학", 78);
		kim.showStudentInfo();

	}

}
