package ifexample;

import java.util.Scanner;

public class gradeTest {

	public static void main(String[] args) {
		// 
//점수를 입력받아 학점을 출력하는 프로그램
		/*A(90점 이상)
		B(80점이상)
		C(70점 이상)
		D(60점이상)*/
		//변수 int점수grade,문자형charscore(학점abcd)
		Scanner sc =new Scanner(System.in);
		System.out.print("점수를 입력하세요:");
		int score=sc.nextInt();
		char grade = 'A'; //String grade = "A"와 같다
		
		 if(score>=60 && score<70);
		{grade = 'D'
		System.out.println("D입니다.");
		
		}else if
		{(score>=70 && score<80);
		
		}else if(score>=80 &&score<90) {
			System.out.println("B입니다.");
		}
		else
			System.out.println("A입니다.");

		
				
		
	}
	
scan.close;
}
