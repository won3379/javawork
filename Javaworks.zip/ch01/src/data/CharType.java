package data;

public class CharType {

	public static void main(String[] args) {
		// 문자 자료형 - char, String
		// 복제 - alt+ctrl+방향키 아래 
		//ASCII(American standard Code for Information)
		char alpha = 'A';
		System.out.println(alpha);  //A
		System.out.println((int)alpha); //65 ASCII CODE , 형변환 
		int alpha2 = 66;
		System.out.println(alpha2); //66
		System.out.println((char)alpha2); //B
	}
}
